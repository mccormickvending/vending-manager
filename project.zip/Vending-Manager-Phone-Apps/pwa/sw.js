/* offline cache. The version changes whenever the app file changes, so updates arrive on the next open. */
const V = "vbm-ba5586d0af";
const FILES = ["./", "index.html", "manifest.webmanifest", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png", "vendor/barcode-detector-polyfill.js", "vendor/zxing_reader.wasm"];
self.addEventListener("install", e => { e.waitUntil(caches.open(V).then(c => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  if(e.request.method !== "GET") return;
  const u = new URL(e.request.url);
  if(u.origin !== location.origin) return;
  e.respondWith(caches.match(e.request, {ignoreSearch:true}).then(r => r || fetch(e.request).catch(() => caches.match("index.html"))));
});
