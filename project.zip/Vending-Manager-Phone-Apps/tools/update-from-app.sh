#!/bin/sh
# Rebuilds the web app (pwa/) and the store apps' web files (www/) from a new Vending-Business-Manager.html.
# usage: sh tools/update-from-app.sh /path/to/Vending-Business-Manager.html
set -e
cd "$(dirname "$0")"
python3 build.py "$1"
rm -rf ../pwa ../www && cp -r pwa ../pwa && cp -r www ../www && cp privacy.html ../pwa/privacy.html && rm -rf pwa www
cd .. && npx cap sync
echo "Done. Commit and push to publish the web app; run the Android/iOS workflows to build the store apps."
