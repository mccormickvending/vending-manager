#!/usr/bin/env python3
"""Builds the phone versions from the single-file app.
   usage: python3 build.py path/to/Vending-Business-Manager.html
   -> pwa/   (installable web app: upload this folder to any static host)
   -> www/   (the same page without the service worker, for the Capacitor store apps)"""
import sys, hashlib, json, os, shutil
src = sys.argv[1] if len(sys.argv) > 1 else '../final/app_v8.html'
html = open(src, encoding='utf-8').read()
ver = hashlib.sha1((html + open(__file__).read()).encode()).hexdigest()[:10]

def must(old, new):
    global html
    assert html.count(old) == 1, old[:60]
    html = html.replace(old, new)

# share-sheet backups: browsers in "installed" mode and the native shell cannot download files normally
share_js = r'''
/* phone builds: send files through the share sheet (Save to Files, Drive, email) */
let VBM_P = null;
function vbmPlugins(){
  if(VBM_P) return VBM_P;
  const C = window.Capacitor;
  if(!(C && C.isNativePlatform && C.isNativePlatform() && typeof C.registerPlugin === "function")) return null;
  return VBM_P = {Filesystem:C.registerPlugin("Filesystem"), Share:C.registerPlugin("Share")};
}
function vbmNative(){ return !!vbmPlugins(); }
function vbmInstalled(){ return !!((window.matchMedia && matchMedia("(display-mode: standalone)").matches) || navigator.standalone); }
function vbmB64(data){ if(typeof data === "string") return btoa(unescape(encodeURIComponent(data))); let s = ""; const u = new Uint8Array(data); for(let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
async function vbmShareFile(name, data, type){
  if(vbmNative()){
    const P = vbmPlugins();
    const w = await P.Filesystem.writeFile({path:name, data:vbmB64(data), directory:"CACHE"});
    await P.Share.share({title:name, url:w.uri, dialogTitle:"Save or send " + name});
    return true;
  }
  if(vbmInstalled() && navigator.canShare && navigator.share){
    const f = new File([data], name, {type:type || "application/octet-stream"});
    if(navigator.canShare({files:[f]})){ await navigator.share({files:[f], title:name}); return true; }
  }
  return false;
}
'''
must('function download(name, text, type){\n', share_js + 'function download(name, text, type){\n  if(/^text\\/csv/.test(type || "") && typeof text === "string" && text.charCodeAt(0) !== 0xFEFF) text = "\\uFEFF" + text;\n  if(vbmNative() || vbmInstalled()){ vbmShareFile(name, text, type).then(ok => { if(!ok) vbmBrowserDownload(name, text, type); }).catch(e => { if(!e || e.name !== "AbortError") vbmBrowserDownload(name, text, type); }); return; }\n  vbmBrowserDownload(name, text, type);\n}\nfunction vbmBrowserDownload(name, text, type){\n')

head_tags = ('<link rel="manifest" href="manifest.webmanifest">\n<link rel="apple-touch-icon" href="apple-touch-icon.png">\n'
 '<link rel="icon" type="image/png" href="icon-192.png">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-capable" content="yes">\n'
 '<meta name="apple-mobile-web-app-title" content="Vending Manager">\n<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n')
html = html.replace('<meta name="viewport" content="width=device-width, initial-scale=1">', '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">' , 1)

NATIVE_TAIL = '<script>\n/* ---- store-app extras: PDF instead of print, hide browser-only backup options ---- */\n(function(){\n  if(typeof vbmNative !== "function" || !vbmNative()) return;\n  document.documentElement.classList.add("vbm-native");\n  const load = src => new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); });\n  let libs = null;\n  async function makePdf(){\n    libs = libs || Promise.all([load("vendor/html2canvas-pro.min.js"), load("vendor/jspdf.umd.min.js")]);\n    try{ await libs; }catch(e){ libs = null; uiAlert("The PDF tools could not be loaded."); return; }\n    const view = document.getElementById("view"), theme = curTheme();\n    toast("Making the PDF…");\n    window.__printing = true; applyTheme("light"); try{ applyAppearance(); }catch(e){} document.documentElement.classList.add("vbm-pdf");\n    try{\n      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));\n      const W = Math.min(2400, Math.max(1040, ...Array.from(view.querySelectorAll("table")).map(t => t.scrollWidth + 60)));\n      const h2c = window.html2canvas && (typeof window.html2canvas === "function" ? window.html2canvas : window.html2canvas.default);\n      const canvas = await h2c(view, {scale:2, backgroundColor:"#ffffff", useCORS:true, logging:false, windowWidth:W + 60, onclone:function(d){ const v = d.getElementById("view"); if(v){ v.style.width = W + "px"; v.style.maxWidth = "none"; } }});\n      const pdf = new jspdf.jsPDF({unit:"pt", format:"letter", orientation:W > 1300 ? "landscape" : "portrait"});\n      const pw = pdf.internal.pageSize.getWidth(), ph = pdf.internal.pageSize.getHeight(), m = 28;\n      const iw = pw - m * 2, scale = iw / canvas.width, sliceH = Math.floor((ph - m * 2) / scale);\n      for(let y = 0, n = 0; y < canvas.height; y += sliceH, n++){\n        const h = Math.min(sliceH, canvas.height - y), c = document.createElement("canvas");\n        c.width = canvas.width; c.height = h; c.getContext("2d").drawImage(canvas, 0, y, canvas.width, h, 0, 0, canvas.width, h);\n        if(n) pdf.addPage();\n        pdf.addImage(c.toDataURL("image/jpeg", 0.92), "JPEG", m, m, iw, h * scale);\n      }\n      const title = (document.querySelector("#view h2") || {}).textContent || "report";\n      await vbmShareFile(title.replace(/[^\\w\\- ]+/g, "").trim().replace(/\\s+/g, "-").toLowerCase() + "-" + today() + ".pdf", pdf.output("arraybuffer"), "application/pdf");\n    }catch(e){ if(!e || e.name !== "AbortError") uiAlert("The PDF could not be made: " + ((e && e.message) || "unknown error")); }\n    finally{ document.documentElement.classList.remove("vbm-pdf"); window.__printing = false; applyTheme(theme); try{ applyAppearance(); }catch(e){} }\n  }\n  window.print = function(){ makePdf(); };\n  /* automatic backup to a chosen file and Google Drive sign-in are browser features; the app uses Export backup */\n  try{ fileCardHTML = function(){ return ""; }; }catch(e){}\n  try{ cloudCardHTML = function(){ return \'<div class="card clcard"><b>Sync between devices</b><p class="note">Coming in a later update. For now, use <b>Export backup</b> to save a copy to Files, Google Drive or email, and <b>Import backup</b> on another device.</p></div>\'; }; }catch(e){}\n  const st = document.createElement("style");\n  st.textContent = ".vbm-pdf .noprint,.vbm-pdf .topbar,.vbm-pdf .banner,.vbm-pdf .calbanner{display:none!important}.vbm-pdf #view{background:#fff}.vbm-pdf *{transition:none!important;animation:none!important}.vbm-pdf .wrap,.vbm-pdf .card,.vbm-pdf .tablewrap{overflow:visible!important}";\n  document.head.appendChild(st);\n  if(typeof render === "function") try{ render(); }catch(e){}\n})();\n</script>\n'
WORDING = [('this browser on this computer', 'this app on this phone'), ('this browser, on this computer', 'this app, on this phone'), ('inside this browser', 'inside this app'), ('in this browser', 'in this app'), ('from this browser', 'from this app'), ('This browser', 'This app'), ('this browser', 'this app')]
def write(dirname, with_pwa):
    shutil.rmtree(dirname, ignore_errors=True); os.makedirs(dirname)
    h = html
    if not with_pwa:
        for a, b in WORDING: h = h.replace(a, b)
        h = h.replace('<title>Vending Business Manager</title>', '<title>Vending Business Manager</title>\n<script src="capacitor.js"></script>', 1)
        i = h.rfind('</body>'); h = h[:i] + NATIVE_TAIL + h[i:]
    if with_pwa:
        h = h.replace('<title>Vending Business Manager</title>', '<title>Vending Business Manager</title>\n' + head_tags, 1)
        reg = '<script>if("serviceWorker" in navigator && /^https?:$/.test(location.protocol)){ window.addEventListener("load", function(){ navigator.serviceWorker.register("sw.js").catch(function(){}); }); }</script>\n</body>'
        i = h.rfind('</body>'); assert i > 0
        h = h[:i] + reg + h[i + len('</body>'):]
    vend = ('<script src="vendor/barcode-detector-polyfill.js"></script>\n<script>try{ BarcodeDetectionAPI.setZXingModuleOverrides({locateFile:function(p, prefix){ return /\\.wasm$/.test(p) ? "vendor/zxing_reader.wasm" : prefix + p; }}); }catch(e){}</script>\n')
    h = h.replace('<title>Vending Business Manager</title>', '<title>Vending Business Manager</title>\n' + vend, 1)
    os.makedirs(dirname + '/vendor')
    for f in os.listdir('vendor_src'): shutil.copy('vendor_src/' + f, dirname + '/vendor/' + f)
    if not with_pwa:
        shutil.copy('vendor_native/capacitor.js', dirname + '/capacitor.js')
        for f in os.listdir('vendor_native'):
            if f != 'capacitor.js': shutil.copy('vendor_native/' + f, dirname + '/vendor/' + f)
    open(dirname + '/index.html', 'w', encoding='utf-8').write(h)
    for f in ['icon-192.png','icon-512.png','icon-maskable-512.png','apple-touch-icon.png']:
        shutil.copy('pwa_assets/' + f, dirname + '/' + f)

os.makedirs('pwa_assets', exist_ok=True)
for f in ['icon-192.png','icon-512.png','icon-maskable-512.png','apple-touch-icon.png','icon-1024.png']:
    if os.path.exists('pwa/' + f): pass
write('pwa', True); write('www', False)

manifest = {"name":"Vending Business Manager","short_name":"Vending Manager","description":"Track machines, stock, sales, expenses and host payouts. Works offline; your data stays on your phone.",
  "start_url":"./","scope":"./","display":"standalone","orientation":"any","background_color":"#0e1d1a","theme_color":"#0e1d1a",
  "icons":[{"src":"icon-192.png","sizes":"192x192","type":"image/png"},{"src":"icon-512.png","sizes":"512x512","type":"image/png"},{"src":"icon-maskable-512.png","sizes":"512x512","type":"image/png","purpose":"maskable"}]}
json.dump(manifest, open('pwa/manifest.webmanifest', 'w'), indent=1)
sw = '''/* offline cache. The version changes whenever the app file changes, so updates arrive on the next open. */
const V = "vbm-%s";
const FILES = ["./", "index.html", "manifest.webmanifest", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png", "vendor/barcode-detector-polyfill.js", "vendor/zxing_reader.wasm"];
self.addEventListener("install", e => { e.waitUntil(caches.open(V).then(c => c.addAll(FILES.map(f => new Request(f, {cache:"reload"})))).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  if(e.request.method !== "GET") return;
  const u = new URL(e.request.url);
  if(u.origin !== location.origin) return;
  e.respondWith(caches.match(e.request, {ignoreSearch:true}).then(r => r || fetch(e.request).catch(() => caches.match("index.html"))));
});
''' % ver
open('pwa/sw.js', 'w').write(sw)
print('built version', ver)
