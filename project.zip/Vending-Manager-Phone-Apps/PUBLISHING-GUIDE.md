# Vending Manager: phone apps, ready to publish

Everything that can be prepared without paying is done. This folder is a complete project for:

- **Web app (free, works on iPhone and Android today).** Folder `pwa/`.
- **Android app for Google Play.** Folder `android/`.
- **iPhone app for the App Store.** Folder `ios/`.

All three use the same app. The store apps are the web app inside a native shell (a tool called Capacitor). On PC, the same web app installs from Chrome or Edge ("Install app" in the address bar).

In the store apps:
- Export backup, Excel, CSV, the accountant zip and the calendar export open the phone's share sheet (save to Files, Google Drive, email).
- "Print, or save as PDF" makes a PDF of the page and opens the share sheet.
- The browser-only backup options (automatic backup file, Google Drive sign-in) are hidden; a "Sync between devices" card says it is coming.
- Wording says "this app" instead of "this browser".
- Barcode scanning works on iPhone too (a scanner is bundled, because iPhone browsers have none built in).

## What was tested here, and what was not

Tested here: the web app installs and runs offline; the share-sheet backup; barcode decoding; all 24 pages draw at phone and desktop sizes. The store-app web files were also tested with a simulated phone shell: backups, CSV and PDF reach the share sheet, and the hidden Settings cards stay hidden.

**Not tested: the Android and iPhone builds themselves.** This workspace cannot download Google's Android build tools and has no Mac, so nobody has compiled or run the store apps yet. Step 2 below builds an Android test app in the cloud so you can find any problems before paying for anything.

## Part 1. Put the web app online (free, no cards)

1. Make a free GitHub account and a new **public** repository, and upload this whole folder to it. (GitHub Pages is free only for public repositories, as far as I know. Public means anyone can see the app's code and use the web app. You said that is fine for now; a private repository needs a paid GitHub plan.)
2. In the repository, open Settings > Pages and set Source to "GitHub Actions".
3. Open the Actions tab, pick "Publish web app" and press Run workflow. A few minutes later it shows the web address.
4. On an iPhone, open that address in Safari, tap Share, then Add to Home Screen. On Android, open it in Chrome and choose Install app. It then opens full screen and works offline.

The privacy policy page is at that address plus `/privacy.html`. You will need that link for both stores.

## Part 2. Test the Android app (free)

1. In the same repository, open Actions > "Android build" > Run workflow.
2. When it finishes, download the "vending-manager-debug-apk" file from the run page, unzip it, and send the .apk to an Android phone. Allow installs from that source when asked.
3. Check: it opens; you can add a sale; Export backup and "Print, or save as PDF" (Reports page) open the share sheet; Scan barcodes in a service visit asks for camera permission and reads a barcode; closing and reopening the app keeps your data. Tell me what breaks and I will fix it.

## Part 3. Google Play (when you can pay)

What you need:
- A Google Play developer account. As far as I know the fee is a one-time $25, but check Google's page.
- Use an **organization** account in McCormick Vending, LLC's name. As of November 2026, personal accounts must first run a closed test with 12 testers for 14 days; organization accounts are exempt. Organization accounts need a D-U-N-S number (free to request through Dun & Bradstreet; it can take days to weeks).
- A signing key. Create it once (any computer with Java): `keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`. Keep the file and its passwords somewhere safe. If you lose them, Google can reset the upload key, but it takes time.

Then:
1. In the GitHub repository, add four secrets (Settings > Secrets and variables > Actions): ANDROID_KEYSTORE_BASE64 (the .jks file encoded with `base64 -w0 upload.jks`), ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD.
2. Run "Android build" again. It now also produces `vending-manager-play-bundle` (a .aab file).
3. In Play Console, create the app, upload the .aab, and paste in the text from `listing/store-listing.md`. Screenshots are in `listing/screenshots/android-phone`. Answer the data-safety form with "no data collected, no data shared" (the app sends nothing anywhere).
4. Check the current target-SDK rule before uploading: Google raises the minimum each year. The project targets Android 15 (SDK 35). If Play rejects it, tell me and I will raise it.

## Part 4. Apple App Store (when you can pay)

What you need:
- An Apple Developer Program membership. I believe it is $99 a year, but check Apple's page. Enrolling as an organization also needs a D-U-N-S number.
- An App Store Connect API key (App Store Connect > Users and Access > Integrations) and a distribution certificate and provisioning profile for `com.mccormickvending.vendingmanager`.

Then add the secrets listed at the top of `.github/workflows/ios.yml` and run "iOS build". It builds on a GitHub Mac and uploads to TestFlight. **That workflow has never been run, so expect to fix a few things on the first attempt.** Alternative: a Mac with Xcode can open `ios/App/App.xcworkspace` and archive it directly.

The project includes Apple's required privacy file (`ios/App/App/PrivacyInfo.xcprivacy`: no tracking, no data collected, file-timestamp and settings reasons declared).

Apple's review is the real hurdle. [Apple rejects apps that are little more than a website in a frame](https://www.mobiloud.com/blog/app-store-review-guidelines-webview-wrapper). This app has things a website lacks: native share-sheet backup, a camera barcode scanner, a full offline mode, and a bundled app icon and splash screen. In the review notes, say plainly that all data is stored on the phone, that there is no login, and list those features. If Apple still rejects it under guideline 4.2, we add more native pieces (for example a native tab bar or local reminders) and resubmit.

## Pricing: decide before submitting

- Apple and Google take a cut of sales made inside their apps (commonly 15% to 30%, with reduced rates for small developers).
- If the app is a **paid download**, buyers pay through the store and Gumroad is not involved.
- If it is **free and unlocked by a Gumroad key**, Apple may object (rules on unlocking features bought elsewhere are being changed by court cases as of November 2026, so check current rules first).
- The simplest first launch is a paid app at a price that covers the store's cut. The web app can remain the Gumroad product.

## Updating the apps later

When the main app file changes: `sh tools/update-from-app.sh path/to/Vending-Business-Manager.html`, commit, push, then run the workflows. Raise `versionCode` in `android/app/build.gradle` for each Play upload and the build number in Xcode for each App Store upload.

## Things to know

- PDFs from the store apps are images of the page, split across letter-size pages. A row can be cut at a page break. Good enough for sharing; a proper text PDF is a later improvement.
- The iPhone home-screen web app keeps its data separate from Safari. Deleting the home-screen icon deletes its data.

- Data lives inside the app. Deleting the app deletes the data unless the person exported a backup. The app already nags about backups.
- The bundle ID `com.mccormickvending.vendingmanager` and the name "Vending Manager" are placeholders you can change before the first store upload; they cannot be changed afterwards.
- Photos are kept inside the app with the same limits as in the browser.
