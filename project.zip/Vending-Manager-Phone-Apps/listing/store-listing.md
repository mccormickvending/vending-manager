# Store listing text (paste into Google Play Console and App Store Connect)

## App name
Vending Manager: Route & Sales
(Play: 30 characters max. App Store: 30 characters max. Both fit.)

## Subtitle (App Store, 30 max)
Track machines, stock & hosts

## Short description (Google Play, 80 max)
Run your vending route: sales, stock, expenses and host payouts. Works offline.

## Full description
Stop running your vending machines out of spreadsheets and a shoebox.

Vending Manager keeps track of your machines, your stock, your sales, your expenses and what you owe each host, then turns it into reports whenever you want them. Everything is stored on your phone. There is no account to create, no subscription and no monthly fee.

WHAT IT DOES
- Host deals your way: a percentage of the vend price, a percentage after sales tax, a flat monthly or per-item amount, a product credit, or tiered rates. Each machine can have its own deal.
- Reports for any period, by machine or product, with exports to Excel, PDF and CSV (sent through your phone's share sheet). Host statements ready to hand over with a payout.
- Import sales from your card reader's export instead of retyping. Duplicates are skipped and every import can be undone.
- Service visits: record what you loaded and the cash you counted, get a load-the-van pick list from your par levels, and see which machines keep coming up short.
- In the field: count cash by bill and coin, add photos of machines and receipts, scan product barcodes, and get directions to every stop.
- Stock and reorder flags, profit by machine, which products earn their slot, estimated card fees, sales tax collected and a monthly summary for your bookkeeper.
- Calendar, timeline and to-do list for restock days, licenses and tax dates.
- Light and dark mode. Works without a signal.

PRIVATE BY DESIGN
Your sales data stays on your phone and is never sent to anyone. Back it up with one tap to Files, Google Drive or email.

The app organizes the figures you enter. It does not prepare or file taxes and is not tax, legal or financial advice. No income is promised or implied.

## Keywords (App Store, 100 characters max)
vending,route,machine,inventory,sales,expenses,host,commission,restock,bookkeeping,small business

## Category
Business (both stores)

## Contact / support URL / privacy URL
Support email: jordanr@mccormickvending.com
Privacy policy: <your web address>/privacy.html (see PUBLISHING-GUIDE.md, part 1)
Support/marketing URL: https://mccormickvending.com/vending-software

## Age rating
Everyone / 4+. No user-generated content shared, no ads, no purchases other than the app itself.

## Google Play data-safety answers
Data collected: none. Data shared: none. Data encrypted in transit: not applicable (no data leaves the device). Users can request deletion: delete the app or use Erase everything.

## App Store privacy "nutrition label"
Data not collected.

## Notes for App Review (App Store)
No login is needed. All data is stored on the device and nothing is sent to a server. Tap "Load sample data" on the first screen (or Settings & Backup > Load sample data) to fill the app with fake data. Native features: share-sheet backup (Settings & Backup > Export backup), camera barcode scanning (Service Visits > New visit > Scan barcodes), photo capture for machines and receipts, full offline use.

## Copyright
© 2026 McCormick Vending, LLC
