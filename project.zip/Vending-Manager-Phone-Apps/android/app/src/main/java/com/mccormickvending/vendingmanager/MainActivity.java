package com.mccormickvending.vendingmanager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
